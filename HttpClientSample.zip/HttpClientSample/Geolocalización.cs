﻿using System;

namespace HttpClientSample
{
    public class Geolocalización
    {
        public string countryCode { get; set; }
        public string countryCode3 { get; set; }
        public string countryName { get; set; }
        public string countryEmoji { get; set; }
    }
}


