Correr comandos en orden dento del directorio local

docker build -t dockerdemo .
docker run dockerdemo: latest
